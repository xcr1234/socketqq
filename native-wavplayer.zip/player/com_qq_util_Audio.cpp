#include "com_qq_util_Audio.h"

#include <iostream>
#include <stdlib.h>
#include <assert.h>
#include <Windows.h>
#include <mmsystem.h>
#pragma comment(lib,"WinMM.Lib")



BOOL MByteToWChar(LPCSTR,LPWSTR,DWORD);
JNIEXPORT void JNICALL Java_com_qq_util_Audio_play
		(JNIEnv *env, jobject obj, jstring str){

	const char *file = env->GetStringUTFChars(str, NULL);
	wchar_t wText[256] = { 0 };
	std::string s = std::string(file);
	MByteToWChar(s.c_str(), wText, sizeof(wText) / sizeof(wText[0]));
	PlaySound(wText, NULL, SND_FILENAME | SND_SYNC);

}


BOOL MByteToWChar(LPCSTR lpcszStr, LPWSTR lpwszStr, DWORD dwSize)
{
	// Get the required size of the buffer that receives the Unicode 
	// string. 
	DWORD dwMinSize;
	dwMinSize = MultiByteToWideChar(CP_ACP, 0, lpcszStr, -1, NULL, 0);
	assert(dwSize >= dwMinSize);

	// Convert headers from ASCII to Unicode.
	MultiByteToWideChar(CP_ACP, 0, lpcszStr, -1, lpwszStr, dwMinSize);
	return TRUE;
}

